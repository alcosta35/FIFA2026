#!/usr/bin/env python3
"""
WC2026 Bolão – API Server
Saves bets to a JSON file on disk.

Install:  pip3 install flask flask-cors
Run:      python3 api.py
Systemd:  see wc2026.service
"""
import json, os, threading
from datetime import datetime, timezone
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

DATA_FILE = os.environ.get("WC_DATA_FILE", "/opt/wc2026/bets.json")
_lock = threading.Lock()


# ── helpers ──────────────────────────────────────────────────
def _read():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        return json.load(f)

def _write(bets):
    os.makedirs(os.path.dirname(DATA_FILE), exist_ok=True)
    tmp = DATA_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(bets, f, indent=2, ensure_ascii=False)
    os.replace(tmp, DATA_FILE)   # atomic on Linux


# ── routes ───────────────────────────────────────────────────
@app.route("/api/bet", methods=["POST"])
def save_bet():
    """Receive a player's bet and append to bets.json."""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "No JSON body"}), 400

    player = data.get("player", {})
    if not player.get("name") or not player.get("email"):
        return jsonify({"error": "Missing player name or email"}), 400

    with _lock:
        bets = _read()
        bet_id = f"bet_{int(datetime.now(timezone.utc).timestamp() * 1000)}"
        bet = {
            "id": bet_id,
            **data,
            "submittedAt": datetime.now(timezone.utc).isoformat()
        }
        bets.append(bet)
        _write(bets)

    app.logger.info(f"Saved bet {bet_id} for {player.get('name')}")
    return jsonify({"ok": True, "id": bet_id}), 201


@app.route("/api/bets", methods=["GET"])
def list_bets():
    """Admin: list all bets (add auth if you want it protected)."""
    with _lock:
        bets = _read()
    # Return a summary (full data on ?full=1)
    if request.args.get("full") == "1":
        return jsonify({"count": len(bets), "bets": bets})
    summary = [
        {
            "id": b["id"],
            "name": b.get("player", {}).get("name", ""),
            "email": b.get("player", {}).get("email", ""),
            "champion": b.get("champion", ""),
            "submittedAt": b.get("submittedAt", "")
        }
        for b in bets
    ]
    return jsonify({"count": len(bets), "bets": summary})


@app.route("/api/health", methods=["GET"])
def health():
    with _lock:
        count = len(_read())
    return jsonify({"status": "ok", "bets": count})


# ── main ─────────────────────────────────────────────────────
if __name__ == "__main__":
    host = os.environ.get("WC_HOST", "127.0.0.1")
    port = int(os.environ.get("WC_PORT", "5050"))
    print(f"[WC2026] API listening on http://{host}:{port}")
    print(f"[WC2026] Data file: {DATA_FILE}")
    app.run(host=host, port=port, debug=False)
